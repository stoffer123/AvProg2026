﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opgave2
{
    internal enum EKulør
    {
        INGEN,
        SPAR,
        HJERTER,
        KLØR,
        RUDER
    }
}
