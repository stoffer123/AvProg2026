﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Opgave2
{
    internal enum ERang
    {
        ES = 1, //Starter ES værdien på 1, så TI bliver 10
        TO, TRE, FIRE, FEM, SEKS, SYV, OTTE, NI, TI,
        KNÆGT,
        DAME,
        KONGE,
        JOKER
    }
}
