﻿using FodboldKlub.Services;
using Microsoft.AspNetCore.Mvc;

namespace FodboldKlub.Controllers
{
    public class MedlemmerController : Controller
    {
        private readonly IMedlemRepository _medlemRepository;

        public MedlemmerController(IMedlemRepository medlemRepo)
        {
            _medlemRepository = medlemRepo;
        }


        public IActionResult Index()
        {
            var medlemmer = _medlemRepository.HentAlle();
            return View(medlemmer);
        }

        public IActionResult Opret()
        {
            return View();
        }
    }
}
